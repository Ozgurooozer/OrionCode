"""3. TERMİNAL — izleyici. `python izle.py [kanal.jsonl]`
Sadece OKUR, asla yazmaz. İki ajanın konuşmasını renkli ve etiketli gösterir."""
import json, sys, time
from pathlib import Path

YOL = Path(sys.argv[1] if len(sys.argv) > 1 else ".tayf/kanal.jsonl")
R = {"A": "\033[36m", "B": "\033[35m"}          # cyan / magenta
K = {"[TEST]": "\033[32m", "[SEZGİ]": "\033[33m", "[ÖLÇÜLMEDİ]": "\033[31m",
     "[TAHMİN]": "\033[33m", "[YAZILDI-KOŞULMADI]": "\033[33m"}
SIFIRLA = "\033[0m"

print(f"TAYF izleyici — {YOL}\n{'='*70}")
imlec = 0
while True:
    if YOL.exists():
        satirlar = YOL.read_text(encoding="utf-8").splitlines()
        for s in satirlar[imlec:]:
            if not s.strip():
                continue
            m = json.loads(s)
            renk = R.get(m["kimden"], "")
            krenk = K.get(m["kanit"], "")
            dyn = f" ←{','.join(m['dayanak'])}" if m["dayanak"] else ""
            print(f"{renk}m{m['seq']:04d} {m['kimden']}→{m['kime']} "
                  f"[{m['tur']}]{SIFIRLA} {krenk}{m['kanit']}{SIFIRLA}{dyn}")
            print(f"      {m['govde']}\n")
        imlec = len(satirlar)
    time.sleep(0.5)
