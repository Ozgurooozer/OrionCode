"""
sozluk — /tayf++ sıkıştırılmış protokol dili.

TEHLİKE: İki ajanın kendi kısaltmalarını uydurup evrimleştirmesi, tam olarak
kriptomnezidir — sembol TANIDIK gelir, tanımı kaymıştır, kimse fark etmez.
Sıkıştırma kazancı, anlam kaybını gizler.

ÇÖZÜM (vault.py'daki çapa ilkesinin protokole uygulanması):
  1. Her sembol bir TANIMA çapalıdır; çapa OKUMA ANINDA çözülür, saklanmaz.
  2. Tanımı çözülemeyen sembol "bilinmeyen" değil, ÇAPASIZ'dır: kullanılamaz,
     açık yazıma dönülür. Sessizce tahmin YOK.
  3. Sembol ancak KANITLA girer: aynı ifade açık halde >= ESIK kez geçmiş
     olmalı. "Kısaltsak güzel olur" yeterli değil (META kural 2).
  4. Sembol ancak KANITLA çıkar: N tur hiç kullanılmadıysa emekli.

# ASSUMPTION(cozum-okuma-aninda): tanim SAKLANMAZ, sozluk'ten çözülür. Mesajın
# içine gömülen kopya tanım bayatlar ve yalan söyler.

ARAYÜZ:
  Sozluk(esik=3)
    .gozlemle(ifade)          ; açık kullanımı say (kanıt biriktir)
    .oner(sembol, ifade) -> bool  ; eşik dolmadıysa False, girmez
    .coz(sembol) -> str       ; çapasızsa ÇapasizSembol fırlatır
    .ac(metin) -> str         ; metindeki sembolleri açar
    .sil(sembol)              ; emeklilik
    .rapor() -> dict          ; kaç sembol, kaç çapasız kullanım denemesi
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

_SEMBOL = re.compile(r"§([a-zA-Z0-9_]+)")


class CapasizSembol(Exception):
    """Tanımı çözülemeyen sembol kullanıldı. Açık yazıma dön."""


@dataclass
class Kayit:
    ifade: str
    kaynak_mesaj: str        # hangi mesajda tanımlandı (çapa)
    kullanim: int = 0


@dataclass
class Sozluk:
    esik: int = 3
    _tanim: dict[str, Kayit] = field(default_factory=dict)
    _gozlem: dict[str, int] = field(default_factory=dict)
    capasiz_deneme: int = 0

    # --- kanıt biriktirme ----------------------------------------------
    def gozlemle(self, ifade: str) -> int:
        """Açık ifade kullanıldı. Sembol adayı olması için sayılır."""
        n = self._gozlem.get(ifade, 0) + 1
        self._gozlem[ifade] = n
        return n

    def oner(self, sembol: str, ifade: str, kaynak_mesaj: str = "") -> bool:
        """
        Sembolü sözlüğe al. KANIT YOKSA GİRMEZ.
        Kanıt = ifade açık halde en az `esik` kez gözlemlendi.
        """
        if not sembol or not sembol.isidentifier():
            raise ValueError(f"geçersiz sembol adı: {sembol!r}")
        if self._gozlem.get(ifade, 0) < self.esik:
            return False
        self._tanim[sembol] = Kayit(ifade, kaynak_mesaj)
        return True

    # --- çözme ----------------------------------------------------------
    def coz(self, sembol: str) -> str:
        k = self._tanim.get(sembol)
        if k is None:
            self.capasiz_deneme += 1
            raise CapasizSembol(
                f"§{sembol} tanımsız. Tahmin etme; açık yaz ve {self.esik} "
                f"kullanımdan sonra tekrar öner.")
        k.kullanim += 1
        return k.ifade

    def ac(self, metin: str) -> str:
        """Metindeki tüm sembolleri açar. Biri çapasızsa PATLAR, yutmaz."""
        def _degistir(m):
            return self.coz(m.group(1))
        return _SEMBOL.sub(_degistir, metin)

    def sikistir(self, metin: str) -> str:
        """Bilinen ifadeleri sembole çevirir. Uzun ifadeden kısaya doğru."""
        for s, k in sorted(self._tanim.items(),
                           key=lambda kv: -len(kv[1].ifade)):
            metin = metin.replace(k.ifade, f"§{s}")
        return metin

    def sil(self, sembol: str) -> None:
        self._tanim.pop(sembol, None)

    def rapor(self) -> dict:
        kullanilmayan = [s for s, k in self._tanim.items() if k.kullanim == 0]
        return {"sembol": len(self._tanim),
                "capasiz_deneme": self.capasiz_deneme,
                "hic_kullanilmayan": kullanilmayan,
                "aday": [i for i, n in self._gozlem.items()
                         if n >= self.esik and not any(
                             k.ifade == i for k in self._tanim.values())]}
