"""DÜŞMAN TESTLERİ — naif çok-ajanlı sohbet tasarımını kıran senaryolar."""
import json, threading, time
import pytest
from pathlib import Path

from kanal import Kanal, Mesaj, KanitTerfiHatasi
from sira import Sira
from sozluk import Sozluk, CapasizSembol
from kiralama import Kiralama


@pytest.fixture
def kanal(tmp_path):
    return Kanal(tmp_path / "tayf.jsonl")


# --- kanal: çok yazarlı güvenlik -------------------------------------
def test_ASIL_es_zamanli_yazma_kayipsiz(kanal):
    """Naif O_APPEND: iki ajan aynı anda yazınca satır bozulur/kaybolur."""
    def yaz(ad, n):
        for i in range(n):
            kanal.yaz(Mesaj(ad, "*", "RAPOR", f"{ad}-{i}"))
    t = [threading.Thread(target=yaz, args=(a, 25)) for a in ("A", "B")]
    [x.start() for x in t]; [x.join() for x in t]
    satirlar = Path(kanal.yol).read_text(encoding="utf-8").splitlines()
    assert len(satirlar) == 50, f"mesaj kaybı: {len(satirlar)}"
    for s in satirlar:
        json.loads(s)                      # bozuk satır varsa patlar
    assert len({json.loads(s)["seq"] for s in satirlar}) == 50, "seq çakıştı"


def test_bos_govde_ve_bilinmeyen_tur_reddedilir(kanal):
    with pytest.raises(ValueError):
        kanal.yaz(Mesaj("A", "B", "SORU", "   "))
    with pytest.raises(ValueError):
        kanal.yaz(Mesaj("A", "B", "UCMAK", "x"))


def test_ASIL_kanit_terfi_edilemez(kanal):
    """B, A'nın [SEZGİ]'sini alıntılarken [TEST] iddia edemez."""
    a = kanal.yaz(Mesaj("A", "B", "RAPOR", "önbellek hızlandırır", "[SEZGİ]"))
    with pytest.raises(KanitTerfiHatasi):
        kanal.yaz(Mesaj("B", "A", "KARAR", "önbellek ekliyorum",
                        "[TEST]", dayanak=[a.mid]))
    # aynı seviye veya aşağısı serbest
    kanal.yaz(Mesaj("B", "A", "KARAR", "deneyeceğim", "[SEZGİ]", dayanak=[a.mid]))


def test_kendi_olcumu_dayanaksiz_test_olabilir(kanal):
    kanal.yaz(Mesaj("A", "B", "RAPOR", "sezgi", "[SEZGİ]"))
    kanal.yaz(Mesaj("B", "A", "RAPOR", "ölçtüm: 3.2x", "[TEST]"))  # dayanak yok


def test_olmayan_dayanak_reddedilir(kanal):
    with pytest.raises(ValueError):
        kanal.yaz(Mesaj("A", "B", "SORU", "x", "[SEZGİ]", dayanak=["m0099"]))


def test_imlec_tekrar_okumaz(kanal):
    kanal.yaz(Mesaj("A", "B", "SORU", "bir"))
    m1, i1 = kanal.oku(0)
    kanal.yaz(Mesaj("A", "B", "SORU", "iki"))
    m2, _ = kanal.oku(i1)
    assert len(m1) == 1 and len(m2) == 1 and m2[0].govde == "iki"


# --- sıra: kilitlenme ------------------------------------------------
def test_ASIL_karsilikli_bekleme_kilitlenmez(kanal):
    """İki taraf da beklerse sistem donmamalı; zaman aşımı sırayı geri alır."""
    s = Sira(kanal, "A", "B", baslangicta_bende=False)
    t0 = time.time()
    gelen, asim = s.bekle_veya_al(saniye=1.0)
    assert asim is True and gelen == [] and s.bende_mi() is True
    assert time.time() - t0 < 3.0
    kayit, _ = kanal.oku(0)
    assert any(m.tur == "ZAMAN_ASIMI" for m in kayit), "sessizlik kayda geçmeli"


def test_sira_disinda_konusmak_reddedilir(kanal):
    s = Sira(kanal, "A", "B", baslangicta_bende=False)
    with pytest.raises(PermissionError):
        s.konus(Mesaj("A", "B", "SORU", "sıram değil"))


def test_konusunca_sira_devreder(kanal):
    s = Sira(kanal, "A", "B", baslangicta_bende=True)
    s.konus(Mesaj("A", "B", "SORU", "hazır mısın?"))
    assert s.bende_mi() is False


# --- sözlük: çapalı sıkıştırma ---------------------------------------
def test_ASIL_capasiz_sembol_tahmin_edilmez():
    """Tanımsız sembol sessizce yorumlanmaz — kriptomnezi koruması."""
    s = Sozluk()
    with pytest.raises(CapasizSembol):
        s.ac("§xyz yapalım")
    assert s.capasiz_deneme == 1


def test_sembol_kanitsiz_giremez():
    s = Sozluk(esik=3)
    assert s.oner("prv", "provenance çapası") is False   # hiç gözlem yok
    for _ in range(3):
        s.gozlemle("provenance çapası")
    assert s.oner("prv", "provenance çapası") is True


def test_tanim_silinince_sembol_capasizlasir():
    s = Sozluk(esik=1)
    s.gozlemle("kanıt terfi kontrolü"); s.oner("kt", "kanıt terfi kontrolü")
    assert s.ac("§kt lazım") == "kanıt terfi kontrolü lazım"
    s.sil("kt")
    with pytest.raises(CapasizSembol):
        s.ac("§kt lazım")


def test_sikistir_ve_ac_tersinir():
    s = Sozluk(esik=1)
    for i in ("ölçüm aletini kalibre et", "kanıt etiketi"):
        s.gozlemle(i)
    s.oner("kal", "ölçüm aletini kalibre et"); s.oner("ke", "kanıt etiketi")
    ham = "önce ölçüm aletini kalibre et, sonra kanıt etiketi yaz"
    assert s.ac(s.sikistir(ham)) == ham


def test_rapor_kullanilmayani_gosterir():
    s = Sozluk(esik=1)
    s.gozlemle("a"); s.oner("x", "a")
    assert "x" in s.rapor()["hic_kullanilmayan"]


# --- kiralama: paylaşılan terminal -----------------------------------
def test_okuma_komutu_kira_istemez(tmp_path):
    k = Kiralama(tmp_path / "kira.json")
    assert "pytest" in k.calistir("A", "python -m pytest -q")


def test_ASIL_yazma_komutu_kirasiz_calismaz(tmp_path):
    k = Kiralama(tmp_path / "kira.json")
    with pytest.raises(PermissionError):
        k.calistir("A", "rm -rf build/")
    assert k.al("A") is True
    k.calistir("A", "rm -rf build/")          # artık serbest


def test_ikinci_ajan_kirayi_alamaz(tmp_path):
    k = Kiralama(tmp_path / "kira.json")
    assert k.al("A") is True and k.al("B") is False
    with pytest.raises(PermissionError):
        k.birak("B")


def test_ASIL_ttl_dolunca_kira_devralinabilir(tmp_path):
    """A çökerse kira sonsuza kadar kilitli kalmamalı."""
    k = Kiralama(tmp_path / "kira.json", ttl=0.3)
    k.al("A")
    assert k.al("B") is False
    time.sleep(0.4)
    assert k.sahip() is None and k.al("B") is True
