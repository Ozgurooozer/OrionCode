"""
sira — konuşma sırası ve KİLİTLENME koruması.

PROBLEM: "cevabı bekleyecek, sonra o cevap verecek" ifadesi, iki taraf da
beklerse sistemi sonsuza kadar dondurur. İnsan sohbetinde bunu sosyal ipuçları
çözer; iki süreçte hiçbir şey çözmez.

ÇÖZÜM: açık SIRA JETONU + zaman aşımında jetonu geri alma.
  - Jeton kimdeyse o konuşur. Diğeri bekler.
  - Bekleyen zaman aşımına uğrarsa ZAMAN_ASIMI yazar ve jetonu ALIR.
  - Böylece sistem her durumda ilerler; en kötü ihtimalle biri "cevap gelmedi"
    diyerek devam eder.

# ASSUMPTION(tek-jeton): Aynı anda tek konuşmacı. Paralel çalışma sırayla
# DEĞİL, ayrı görevlerle olur (her ajan kendi işini yapar, kanalda sıra alır).
# İki ajan aynı anda yazarsa kanal.py kilidi korur ama SIRALAMA anlamı kaybolur.

ARAYÜZ:
  Sira(kanal, ben, karsi)
    .bende_mi() -> bool
    .konus(mesaj) -> Mesaj          ; jeton bende değilse PermissionError
    .devret() -> None               ; sırayı karşıya ver
    .bekle_veya_al(saniye) -> (mesajlar, zaman_asimi_oldu_mu)
"""
from __future__ import annotations

from kanal import Kanal, Mesaj


class Sira:
    def __init__(self, kanal: Kanal, ben: str, karsi: str,
                 baslangicta_bende: bool = False) -> None:
        self.k = kanal
        self.ben = ben
        self.karsi = karsi
        self._bende = baslangicta_bende
        self.imlec = 0
        self.zaman_asimi_sayisi = 0

    def bende_mi(self) -> bool:
        return self._bende

    def konus(self, m: Mesaj) -> Mesaj:
        if not self._bende:
            raise PermissionError(
                f"sıra {self.karsi}'da. Beklemeden yazmak iki tarafın aynı anda "
                f"konuşmasına yol açar; bekle_veya_al() kullan.")
        m.kimden, m.kime = self.ben, self.karsi
        yazilan = self.k.yaz(m)
        if m.tur != "BITTI":
            self._bende = False          # konuştun, sıra karşıya geçti
        return yazilan

    def devret(self) -> None:
        self._bende = False

    def bekle_veya_al(self, saniye: float = 60.0
                      ) -> tuple[list[Mesaj], bool]:
        """
        Karşıdan mesaj bekle. Gelmezse ZAMAN_ASIMI yaz ve SIRAYI AL.
        Dönüş: (gelen mesajlar, zaman aşımı oldu mu)
        """
        gelen, self.imlec = self.k.bekle(self.imlec, self.ben, saniye)
        if gelen:
            self._bende = True
            return gelen, False
        # Kilitlenme kırıcı: sessizliği KAYDA GEÇİR, sonra devam et.
        self._bende = True
        self.zaman_asimi_sayisi += 1
        self.k.yaz(Mesaj(
            kimden=self.ben, kime=self.karsi, tur="ZAMAN_ASIMI",
            govde=f"{saniye:.0f}s içinde yanıt gelmedi; sırayı alıyorum.",
            kanit="[TEST]"))
        return [], True
