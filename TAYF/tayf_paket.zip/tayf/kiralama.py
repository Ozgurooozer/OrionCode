"""
kiralama — iki ajanın PAYLAŞTIĞI Orion terminali için kilit.

PROBLEM: İki ajan aynı terminale komut yazarsa çıktılar iç içe geçer ve
"hangi çıktı kimin komutuna ait" bilgisi kaybolur. Daha kötüsü: biri dosya
yazarken diğeri aynı dosyayı okur.

ÇÖZÜM (kortex.py'daki kapının aynısı — geri alma maliyetine göre):
  OKUMA komutu (ls, cat, git status, pytest): geri alınabilir -> KİRA GEREKMEZ.
  YAZMA komutu (edit, rm, git commit, install): geri alınamaz -> KİRA ŞART.

TTL ZORUNLU: kirayı alan ajan çökerse kira sonsuza kadar kilitli kalmamalı.
Süre dolunca kira düşer ve diğer ajan devralabilir.

# ASSUMPTION(tavsiye-kilidi): Bu ADVISORY bir kilittir; kirasız komut çalıştırmayı
# fiziksel olarak engellemez, ajanın uymasını bekler. Zorunlu kılmak için
# komutlar bu modülün üzerinden geçirilmelidir (bkz. calistir()).

ARAYÜZ:
  Kiralama(yol, ttl=120)
    .al(kim) -> bool          ; kira boşsa ya da süresi dolduysa alır
    .birak(kim)               ; sahibi değilse PermissionError
    .sahip() -> str | None    ; süresi dolmuşsa None
    .calistir(kim, komut, yazma) -> str   ; yazma=True ve kira yoksa PermissionError
"""
from __future__ import annotations

import fcntl
import json
import time
from pathlib import Path

# Yazma sayılan komut önekleri. Liste GENİŞLERKEN dikkat: her ekleme
# "bunu geri almak kaç komut sürüyor?" sorusuna cevap vermeli.
YAZMA_ONEKLERI = ("rm", "mv", "cp", "git commit", "git push", "git checkout",
                  "pip install", "npm install", "chmod", "mkdir", ">", ">>",
                  "tee", "sed -i", "python -c", "touch")


class Kiralama:
    def __init__(self, yol: str | Path, ttl: float = 120.0) -> None:
        self.yol = Path(yol)
        self.ttl = ttl
        self.yol.parent.mkdir(parents=True, exist_ok=True)

    def _oku(self) -> dict | None:
        if not self.yol.exists():
            return None
        try:
            d = json.loads(self.yol.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, ValueError):
            return None
        if time.time() - d.get("ts", 0) > self.ttl:
            return None                      # süresi doldu -> kira yok
        return d

    def sahip(self) -> str | None:
        d = self._oku()
        return d["kim"] if d else None

    def al(self, kim: str) -> bool:
        with open(self.yol.with_suffix(".lock"), "w") as g:
            fcntl.flock(g, fcntl.LOCK_EX)
            try:
                d = self._oku()
                if d and d["kim"] != kim:
                    return False             # başkasında, süresi de dolmamış
                self.yol.write_text(
                    json.dumps({"kim": kim, "ts": time.time()}),
                    encoding="utf-8")
                return True
            finally:
                fcntl.flock(g, fcntl.LOCK_UN)

    def birak(self, kim: str) -> None:
        d = self._oku()
        if d and d["kim"] != kim:
            raise PermissionError(f"kira {d['kim']}'da, {kim} bırakamaz")
        self.yol.unlink(missing_ok=True)

    @staticmethod
    def yazma_mi(komut: str) -> bool:
        k = komut.strip()
        return any(o in k for o in YAZMA_ONEKLERI)

    def calistir(self, kim: str, komut: str, kosucu=None) -> str:
        """
        kosucu(komut) -> str  (gerçekte subprocess; testte sahte)
        Yazma komutu kira olmadan çalışmaz.
        """
        if self.yazma_mi(komut) and self.sahip() != kim:
            raise PermissionError(
                f"'{komut}' yazma komutu; kira {self.sahip()!r}'da. "
                f"Önce al('{kim}') çağır.")
        if kosucu is None:
            return f"[{kim}] {komut}"        # kuru çalıştırma
        return kosucu(komut)
