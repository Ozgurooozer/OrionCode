/tayf++ — Sıkıştırılmış protokol moduna geç.

## Ne yapar
Sık kullanılan uzun ifadeleri `§sembol` kısaltmalarına çevirir. Amaç token
tasarrufu ve tetikleme hızı.

## Sıkı kurallar — bunlar olmadan sıkıştırma anlam kaybını gizler
1. **Sembol kanıtla girer.** İfade açık halde en az 3 kez geçmiş olmalı.
   "Kısaltsak güzel olur" gerekçe değildir.
   ```python
   from sozluk import Sozluk
   sz = Sozluk(esik=3)
   sz.gozlemle("ölçüm aletini kalibre et")   # her açık kullanımda
   sz.oner("kal", "ölçüm aletini kalibre et", kaynak_mesaj="m0012")
   ```
2. **Çapasız sembol tahmin edilmez.** `§xyz` tanımsızsa `CapasizSembol`
   fırlatır. Yakalayıp tahmin etme — açık yazıma dön ve tanımı sor.
3. **Tanım saklanmaz, çözülür.** Mesajın içine tanım kopyası gömme; bayatlar.
4. **Emeklilik:** `sz.rapor()["hic_kullanilmayan"]` boş değilse o sembolleri sil.

## Ölçüm (henüz yapılmadı)
`/tayf++`'ın gerçekten hızlandırdığı **[ÖLÇÜLMEDİ]**. Kanıtı: aynı görevi
sıkıştırmalı ve sıkıştırmasız koş, toplam token ve tur sayısını karşılaştır.
Ölçmeden "daha hızlı" deme.
