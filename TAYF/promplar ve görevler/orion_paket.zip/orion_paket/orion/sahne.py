"""
sahne — model anlatımından animasyon olayı çıkarır.

İKİ AKIM (sonification'da doğrulanan yapı):
  POZ  : sürekli durum, değişene kadar kalır   -> [poz:düşünüyor]
  JEST : kesikli olay, çalar ve poza döner     -> [jest:el_salla:yavaş]

Model işaretçileri nesrin İÇİNE gömer; gösterimden önce ayıklanır.
Kullanıcı işaretçileri hiç görmez, animatör nesri hiç görmez.

# ASSUMPTION(stream-split): işaretçi iki chunk'a bölünerek gelebilir
# ("[el_ka" + "ldır:yavaş]"). Ayrıştırıcı TAMPONLAR; chunk başına regex YANLIŞ.
# test_ASIL_bolunmus_isaretci bunu korur.

# ASSUMPTION(no-user-markers): yalnız MODEL çıktısı ayrıştırılır. Kullanıcı
# metnindeki işaretçiler enjeksiyondur; besleme noktasında ayıklanır.

ARAYÜZ:
  Ayristirici.besle(chunk) -> (gorunur_metin, [Olay...])
      Tamamlanmamış işaretçi tamponda kalır, metin olarak SIZMAZ.
  Ayristirici.bitir()      -> (kalan_metin, [Olay...])
      Kapanmamış işaretçi düz metne çevrilir (veri kaybı olmaz).
  temizle(metin) -> str    ; kullanıcı girdisinden işaretçi söker
  Hata modları: ValueError (bilinmeyen poz/jest adı reddedilmez, RAPORLANIR)
"""
from __future__ import annotations

import re
from dataclasses import dataclass

POZLAR = {"nötr", "düşünüyor", "yazıyor", "bekliyor", "şaşkın", "uyuyor"}
JESTLER = {"el_salla", "el_kaldır", "başını_salla", "işaret_et", "omuz_silk"}
HIZLAR = {"yavaş", "normal", "hızlı"}

# Yapıyı GEVŞEK yakala (marka benzeri her şey tüketilsin, sızmasın),
# içeriği Python'da doğrula. Sıkı regex, geçersiz parametrede işaretçinin
# TAMAMINI kaybediyordu ve parantezleri kullanıcıya sızdırıyordu.
_ISARET = re.compile(r"\[(poz|jest):([^\]\[]*)\]")
_ACIK = re.compile(r"\[[^\]\[]*$")     # yarım kalmış işaretçi


@dataclass(frozen=True)
class Olay:
    tur: str          # "poz" | "jest"
    ad: str
    hiz: str
    bilinen: bool     # katalogda var mı


def _cozumle(tur: str, govde: str) -> Olay:
    parcalar = govde.split(":")
    ad = parcalar[0].strip()
    hiz = parcalar[1].strip() if len(parcalar) > 1 else ""
    katalog = POZLAR if tur == "poz" else JESTLER
    # Geçersiz hız işaretçiyi ÖLDÜRMEZ, normale düşer.
    return Olay(tur, ad, hiz if hiz in HIZLAR else "normal", ad in katalog)


def temizle(metin: str) -> str:
    """Kullanıcı girdisinden işaretçi söker: enjeksiyon önlemi."""
    return _ISARET.sub("", metin).replace("[", "(").replace("]", ")")


class Ayristirici:
    def __init__(self) -> None:
        self._tampon = ""
        self.poz = "nötr"
        self.bilinmeyen: list[str] = []

    def besle(self, chunk: str) -> tuple[str, list[Olay]]:
        self._tampon += chunk
        olaylar: list[Olay] = []
        cikti_parcalari: list[str] = []
        son = 0
        for m in _ISARET.finditer(self._tampon):
            cikti_parcalari.append(self._tampon[son:m.start()])
            o = _cozumle(m.group(1), m.group(2))
            if not o.bilinen:
                # GÖZLEMLENEBİLİRLİK: sessizce yutma; bilinmeyeni say.
                self.bilinmeyen.append(o.ad)
            else:
                if o.tur == "poz":
                    self.poz = o.ad
                olaylar.append(o)
            son = m.end()
        kalan = self._tampon[son:]
        # Yarım işaretçi varsa tamponda TUT, metne sızdırma.
        acik = _ACIK.search(kalan)
        if acik:
            cikti_parcalari.append(kalan[:acik.start()])
            self._tampon = kalan[acik.start():]
        else:
            cikti_parcalari.append(kalan)
            self._tampon = ""
        return "".join(cikti_parcalari), olaylar

    def bitir(self) -> tuple[str, list[Olay]]:
        """Akış bitti: kapanmamış işaretçi düz metne döner, kaybolmaz."""
        kalan, self._tampon = self._tampon, ""
        return kalan, []


SISTEM_ISTEMI = """Yanıtlarına hareket işaretçileri göm. Kurallar:
- Duruşun değiştiğinde [poz:X] yaz. X: nötr, düşünüyor, yazıyor, bekliyor, şaşkın, uyuyor.
  Poz değişene kadar sürer; her cümlede tekrar yazma.
- Anlık bir hareket için [jest:Y:hız] yaz. Y: el_salla, el_kaldır, başını_salla,
  işaret_et, omuz_silk. hız: yavaş, normal, hızlı.
- İşaretçiler cümlenin doğal akışı içinde dursun, ayrı satıra alma.
- Yanıt başına en fazla 1 poz değişimi ve 2 jest. Fazlası gürültüdür.
Örnek: "[poz:düşünüyor] Bu ilginç bir soru. [jest:el_kaldır:yavaş] Şöyle bakalım..."
"""
