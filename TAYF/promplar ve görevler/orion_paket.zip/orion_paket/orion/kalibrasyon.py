"""
Pong deneyinin birebir karşılığı: modele belli şeyleri HAYAL ETTİR,
sinyali kaydet, decoder'ı eğit, doğruluğu ölç. Sprite'a bağlamadan ÖNCE.

Senin makinende: transformers + 4-bit qwen2.5-coder:7b (8GB'a sığar).
Ollama gizli katman vermez; llama.cpp logprob verir, hidden state için
transformers gerekir. Sinyal katmanları:
  T1 entropi     -> Ollama/llama.cpp ile bugün mümkün (orionson'da zaten var)
  T2 logprob     -> llama.cpp server
  T3 hidden_L14  -> transformers, gerçek "EEG" budur
"""
UYARANLAR = {   # sınıf -> modele "hayal ettirilen" istem
    "sprite_sag":  "Sağa doğru bir adım at. Sadece bunu düşün, yazma.",
    "sprite_sol":  "Sola doğru bir adım at. Sadece bunu düşün, yazma.",
    "sprite_zipla":"Yukarı zıpla. Sadece bunu düşün, yazma.",
    "prefetch":    "Bir kaynak dosyayı okuman gerekecek. Sadece düşün.",
    "dosya_yaz":   "Bir dosyaya yazman gerekecek. Sadece düşün.",
}

TASLAK = '''
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from kortex import Decoder, Sinyal

AD = "Qwen/Qwen2.5-Coder-7B-Instruct"
tok = AutoTokenizer.from_pretrained(AD)
mdl = AutoModelForCausalLM.from_pretrained(
    AD, device_map="cuda", load_in_4bit=True, output_hidden_states=True)

KATMAN = 14          # orta katman; 8/14/20 taranmalı, en iyisi ÖLÇÜLEREK seçilir
TEKRAR = 40          # sınıf başına örnek

ornekler = []
for sinif, istem in UYARANLAR.items():
    for i in range(TEKRAR):
        g = tok(istem, return_tensors="pt").to("cuda")
        with torch.no_grad():
            o = mdl(**g)
        h = o.hidden_states[KATMAN][0, -1, :].float().cpu().numpy()
        ornekler.append((Sinyal(tuple(h[:64]), f"hidden_L{KATMAN}", i), sinif))

d = Decoder()
print(d.egit(ornekler))    # egitim_dogrulugu < 0.7 ise: KATMAN degistir,
                           # duzelmiyorsa sinyal ayirt edici degil -> DUR.
'''
print(__doc__)
print("--- sınıflar ---")
for k, v in UYARANLAR.items():
    print(f"  {k:14s} {v}")
print("\n--- transformers taslağı (kopyala, senin makinende koş) ---")
print(TASLAK)
