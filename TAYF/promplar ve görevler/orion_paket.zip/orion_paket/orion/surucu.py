"""
surucu — üretici arka uçları. YEREL VARSAYILAN, API opsiyonel.

Tasarım gerekçesi (8GB VRAM / RTX 4060):
  NREM_DERIN mekanik bir iş: özet çıkarma, düşük sıcaklık, tutarlılık ister.
  7B yerel model bunun için yeterli ve uyku boştayken koştuğu için VRAM bedava.
  REM ise üretken: yüksek sıcaklık, uzun menzilli bağlantı. Burada büyük model
  fark yaratabilir — ama BU BİR VARSAYIM, ölçülmedi.

# ASSUMPTION(rem-buyuk-model-fayda): REM'de büyük modelin daha iyi bağlantı
# ürettiği ÖLÇÜLMEDİ. Ölçmeden API'ye para verme; iki kolu da koş, önerileri
# kör olarak puanla (hangisi geldiğini bilmeden).

ARAYÜZ:
  yerel(model, url) -> Callable[[str, float], str]
  api(model)        -> Callable[[str, float], str]   ; ANTHROPIC_API_KEY ister
  kademeli(...)     -> Callable  ; NREM yerel, REM API; anahtar yoksa hepsi yerel
  Hata modları: RuntimeError (arka uç ulaşılamaz), ValueError (sıcaklık aralığı)
"""
from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from typing import Callable

Uretici = Callable[[str, float], str]


def _kontrol(sicaklik: float) -> None:
    if not 0.0 <= sicaklik <= 2.0:
        raise ValueError(f"sıcaklık 0..2 aralığında olmalı: {sicaklik}")


def yerel(model: str = "qwen2.5-coder:7b",
          url: str = "http://localhost:11434/api/chat") -> Uretici:
    def uret(prompt: str, sicaklik: float) -> str:
        _kontrol(sicaklik)
        payload = {"model": model, "stream": False,
                   "options": {"temperature": sicaklik},
                   "messages": [{"role": "user", "content": prompt}]}
        req = urllib.request.Request(
            url, data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=180) as r:
                return json.loads(r.read())["message"]["content"]
        except (urllib.error.URLError, TimeoutError) as e:
            raise RuntimeError(f"Ollama ulaşılamıyor ({url}): {e}") from e
    return uret


def api(model: str = "claude-sonnet-4-6") -> Uretici:
    anahtar = os.environ.get("ANTHROPIC_API_KEY")
    if not anahtar:
        raise RuntimeError("ANTHROPIC_API_KEY yok")

    def uret(prompt: str, sicaklik: float) -> str:
        _kontrol(sicaklik)
        payload = {"model": model, "max_tokens": 512,
                   "temperature": min(sicaklik, 1.0),
                   "messages": [{"role": "user", "content": prompt}]}
        req = urllib.request.Request(
            "https://api.anthropic.com/v1/messages",
            data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json",
                     "x-api-key": anahtar,
                     "anthropic-version": "2023-06-01"})
        try:
            with urllib.request.urlopen(req, timeout=120) as r:
                blocks = json.loads(r.read())["content"]
                return "".join(b.get("text", "") for b in blocks)
        except urllib.error.HTTPError as e:
            raise RuntimeError(f"API {e.code}: {e.read()[:200]!r}") from e
    return uret


def kademeli(rem_esigi: float = 0.7) -> Uretici:
    """
    Sıcaklığa göre yönlendirir: düşük (NREM) -> yerel, yüksek (REM) -> API.
    Anahtar yoksa SESSİZCE yerelde kalır ama bir kez uyarır.
    """
    y = yerel()
    try:
        a = api()
    except RuntimeError:
        a = None
        print("[uyku] ANTHROPIC_API_KEY yok — REM de yerelde koşacak.")

    def uret(prompt: str, sicaklik: float) -> str:
        if a is not None and sicaklik >= rem_esigi:
            return a(prompt, sicaklik)
        return y(prompt, sicaklik)
    return uret
