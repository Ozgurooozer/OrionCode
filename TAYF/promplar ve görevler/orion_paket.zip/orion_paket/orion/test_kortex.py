"""
DÜŞMAN TESTİ — naif "sinyal gelince tool'u ateşle" tasarımını kıran senaryolar.

Kıran senaryo: sınıflandırıcı %99 güvenle "dosya_yaz" der ve sistem yazar.
Sinyal argüman taşımadığı için hangi dosyaya yazacağı halüsine edilir.
Kapı bunu güvenle PAZARLIK ETMEDEN reddetmeli.
"""
import pytest

from kortex import Decoder, Kapi, Kopru, Sinyal, Yol, KATALOG


def ornek(v, etiket, i=0):
    return (Sinyal(tuple(v), "hidden_L14", i), etiket)


EGITIM = (
    [ornek([1.0, 0.0, 0.0], "sprite_sag", i) for i in range(5)]
    + [ornek([0.0, 1.0, 0.0], "sprite_sol", i) for i in range(5)]
    + [ornek([0.0, 0.0, 1.0], "dosya_yaz", i) for i in range(5)]
)


def kur():
    d = Decoder()
    d.egit(EGITIM)
    return Kopru(d, Kapi(esik=0.5))


def test_bos_egitim_reddedilir():
    with pytest.raises(ValueError):
        Decoder().egit([])


def test_egitilmemis_decoder_reddedilir():
    with pytest.raises(ValueError):
        Decoder().coz(Sinyal((1.0, 0.0, 0.0), "x", 0))


def test_tanimsiz_sinif_reddedilir():
    with pytest.raises(ValueError):
        Kapi().gecir("ucmak", 0.99)


def test_ASIL_guven_yetki_degildir():
    """%100 güvenle bile geri alınamaz eylem refleks yolundan geçemez."""
    yol, gerekce = Kapi(esik=0.1).gecir("dosya_yaz", guven=1.0)
    assert yol is Yol.ISTEMLI, "geri alınamaz eylem refleksle ateşlendi"
    assert "geri alınamaz" in gerekce


def test_katalog_geri_alinabilir_ise_parametresiz():
    """Sinyal argüman taşımaz: geri alınabilir+parametreli eylem olamaz."""
    for e in KATALOG.values():
        if e.geri_alinabilir:
            assert e.parametresiz, f"{e.ad} refleks olamaz"


def test_geri_alinabilir_yuksek_guven_reflekse_gider():
    ateslenen = []
    d = Decoder(); d.egit(EGITIM)
    k = Kopru(d, Kapi(esik=0.5), efektor=ateslenen.append)
    karar = k.tik(Sinyal((1.0, 0.0, 0.0), "hidden_L14", 7))
    assert karar.sinif == "sprite_sag" and karar.yol is Yol.REFLEKS
    assert ateslenen == ["sprite_sag"]


def test_dusuk_guven_reddedilir_hicbir_sey_atesLenmez():
    ateslenen = []
    d = Decoder(); d.egit(EGITIM)
    k = Kopru(d, Kapi(esik=0.99), efektor=ateslenen.append)
    karar = k.tik(Sinyal((0.55, 0.45, 0.0), "hidden_L14", 3))
    assert karar.yol is Yol.RED and ateslenen == []


def test_yazma_sinyali_efektoru_asla_atesLemez():
    ateslenen = []
    d = Decoder(); d.egit(EGITIM)
    k = Kopru(d, Kapi(esik=0.1), efektor=ateslenen.append)
    k.tik(Sinyal((0.0, 0.0, 1.0), "hidden_L14", 9))   # net dosya_yaz sinyali
    assert ateslenen == [], "yazma refleksle ateşlendi = uyurgezerlik"


def test_kalibrasyon_ayirt_edilemez_sinyalde_dusuk_dogruluk_verir():
    """
    Ölçüm aleti önce bilinen girdide: TÜM sınıflar aynı vektörse
    doğruluk düşük çıkmalı. Yüksek çıkarsa alet bozuktur.
    """
    ayni = ([ornek([1.0, 1.0], "sprite_sag", i) for i in range(5)]
            + [ornek([1.0, 1.0], "sprite_sol", i) for i in range(5)])
    rapor = Decoder().egit(ayni)
    assert rapor["egitim_dogrulugu"] <= 0.6, rapor


def test_rapor_dagilimi():
    k = kur()
    k.tik(Sinyal((1.0, 0.0, 0.0), "h", 0))
    k.tik(Sinyal((0.0, 0.0, 1.0), "h", 1))
    r = k.rapor()
    assert r["refleks"] == 1 and r["istemli"] == 1
