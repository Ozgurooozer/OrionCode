"""Senin makinende: python kos_uyku.py   (Ollama ayakta olmalı)
ANTHROPIC_API_KEY varsa REM otomatik API'ye çıkar, yoksa hepsi yerel."""
from vault import Vault, format_for_agent
from uyku import UykuMotoru
from surucu import kademeli

v = Vault()
v.write_episode("ep01", "Kullanıcı vault provenance tasarımını seçti: çapa okuma anında çözülür.")
v.write_episode("ep02", "Sonification testinde FFT sızıntısı ölçümü bozmuştu; Hann penceresi çözdü.")
v.write_episode("ep03", "Kuş-Su v7 çatısı: ara temsile değil şeyin kendisine bak.")

m = UykuMotoru(v, kademeli())
m.baski_ekle(60_000)
print("uyumalı mı:", m.uyumali_mi(bosta_sn=0))

r = m.dongu_kos(dongu=1)
print(f"\nkonsolide={r.konsolide} budandi={r.budandi} oneri={r.oneri}")
print(f"REM'de engellenen yazma: {r.engellenen_eylem}")
print("\n--- KARANTİNA (henüz vault'ta değil) ---")
for o in m.karantina:
    print(f"  [{o.oneri_id}] {o.metin}")
print("\n--- ajana sunulan bağlam ---")
print(format_for_agent(v.retrieve("vault çapa ölçüm", k=8)))
