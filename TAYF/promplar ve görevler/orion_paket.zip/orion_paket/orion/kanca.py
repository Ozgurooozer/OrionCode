"""
kanca — sahne olaylarını tüketmesi kolay hale getirir.

İKİ SAAT PROBLEMİ:
  Olaylar ÜRETİM hızında gelir (~30 tok/s), kullanıcı OKUMA hızında tüketir.
  Ayrıştırma anında ateşlersen animasyon, ilgili cümle okunmadan önce oynar.
ÇÖZÜM: olay zaman damgası değil, GÖRÜNÜR METİNDEKİ KARAKTER KONUMU taşır.
  Ne zaman oynayacağına tüketici karar verir:
    daktilo efekti -> yazılan karakter sayısına göre
    TTS            -> sesin o karaktere geldiği ana göre
    anlık gösterim -> hepsi birden
  Ayrıştırıcı zamanlama TAHMİN ETMEZ, çapa verir.

# ASSUMPTION(konum-gorunur-metinde): konum, işaretçiler AYIKLANDIKTAN sonraki
# metne göredir. Ham chunk uzunluğu sayılırsa konumlar kayar; test bunu korur.

İKİ SAAT, İKİ AMAÇ (kortex.py kapısıyla aynı ayrım):
  ANINDA  : refleks/geri alınabilir (prefetch, cache ısıtma)  -> abone("jest", ...)
  KONUMDA : sunum (animasyon)  -> olaylar listesindeki .konum kullanılır

ARAYÜZ:
  Sahne.abone(tur, fn) -> fn        ; tur: "poz" | "jest" | "*"
  Sahne.besle(chunk)   -> (gorunur_metin, [Olay...])
  Sahne.bitir()        -> (kalan, [])
  Sahne.jsonl()        -> Iterator[str]   ; biriken olaylar, satır başına bir JSON
  Callback patlarsa akış ÖLMEZ: loglanır, sayaç artar (Sahne.hatali).
"""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from typing import Callable, Iterator

from sahne import Ayristirici, Olay

log = logging.getLogger("orion.kanca")


@dataclass(frozen=True)
class SahneOlayi:
    tur: str
    ad: str
    hiz: str
    konum: int        # görünür metindeki karakter indeksi

    def dict(self) -> dict:
        return {"tur": self.tur, "ad": self.ad, "hiz": self.hiz,
                "konum": self.konum}


class Sahne:
    def __init__(self) -> None:
        self._a = Ayristirici()
        self._aboneler: dict[str, list[Callable[[SahneOlayi], None]]] = {}
        self._uzunluk = 0          # şimdiye kadarki GÖRÜNÜR metin uzunluğu
        self.olaylar: list[SahneOlayi] = []
        self.hatali = 0

    # --- abonelik (dekoratör olarak da kullanılır) ----------------------
    def abone(self, tur: str, fn: Callable[[SahneOlayi], None] | None = None):
        if fn is None:                        # @sahne.abone("jest") kullanımı
            return lambda f: self.abone(tur, f)
        self._aboneler.setdefault(tur, []).append(fn)
        return fn

    def _yayinla(self, o: SahneOlayi) -> None:
        for tur in (o.tur, "*"):
            for fn in self._aboneler.get(tur, ()):
                try:
                    fn(o)
                except Exception:             # akış bir abone yüzünden ölmesin
                    self.hatali += 1
                    log.exception("abone patladı: %s", o)

    # --- besleme --------------------------------------------------------
    def besle(self, chunk: str) -> tuple[str, list[SahneOlayi]]:
        """
        Not: Ayristirici bir chunk'taki tüm işaretçileri toplu döndürür, o
        yüzden konum bu chunk'ın BAŞLANGICINA sabitlenir. Karakter hassasiyeti
        gerekiyorsa chunk'ları küçült (token başına besle) — kos_sahne.py öyle.
        """
        bas = self._uzunluk
        metin, ham = self._a.besle(chunk)
        yeni = [SahneOlayi(o.tur, o.ad, o.hiz, bas) for o in ham]
        self._uzunluk += len(metin)
        for o in yeni:
            self.olaylar.append(o)
            self._yayinla(o)
        return metin, yeni

    def bitir(self) -> tuple[str, list[SahneOlayi]]:
        kalan, _ = self._a.bitir()
        self._uzunluk += len(kalan)
        return kalan, []

    # --- taşıma ---------------------------------------------------------
    def jsonl(self) -> Iterator[str]:
        """Süreçler arası hat: Godot/Unity/tarayıcı satır satır okur."""
        for o in self.olaylar:
            yield json.dumps(o.dict(), ensure_ascii=False)

    @property
    def poz(self) -> str:
        return self._a.poz

    @property
    def bilinmeyen(self) -> list[str]:
        return self._a.bilinmeyen


TUKETICI_ORNEKLERI = """
# --- Python (aynı süreç) ---
sahne = Sahne()

@sahne.abone("jest")
def oynat(o):
    animator.play(o.ad, speed=o.hiz)      # ANINDA: refleks

@sahne.abone("poz")
def duruş(o):
    animator.set_pose(o.ad)

# --- Godot (GDScript, ayrı süreç, JSONL borusu) ---
# var line = stdout.get_line()
# var e = JSON.parse_string(line)
# if e.tur == "jest": $Anim.play(e.ad)
# # daktilo efektiyle senkron: karakter sayacı e.konum'a ulaşınca oynat

# --- Tarayıcı (SSE) ---
# es.onmessage = ev => { const e = JSON.parse(ev.data);
#   if (typed >= e.konum) play(e.ad); else queue.push(e); }
"""
