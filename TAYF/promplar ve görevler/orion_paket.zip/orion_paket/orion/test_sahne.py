"""DÜŞMAN TESTİ — naif "her chunk'a regex at" tasarımını kıran senaryolar."""
from sahne import Ayristirici, Olay, temizle


def test_ASIL_bolunmus_isaretci():
    """Akışta işaretçi ikiye bölünür. Naif regex kaçırır, metne sızdırır."""
    a = Ayristirici()
    m1, o1 = a.besle("Merhaba [jest:el_ka")
    assert o1 == [] and "[" not in m1, f"yarım işaretçi sızdı: {m1!r}"
    m2, o2 = a.besle("ldır:yavaş] nasılsın")
    assert len(o2) == 1 and o2[0].ad == "el_kaldır" and o2[0].hiz == "yavaş"
    assert (m1 + m2) == "Merhaba  nasılsın"


def test_poz_surer_jest_gecicidir():
    a = Ayristirici()
    a.besle("[poz:düşünüyor] hmm [jest:el_salla] evet")
    assert a.poz == "düşünüyor"


def test_bilinmeyen_isaretci_sessizce_yutulmaz():
    a = Ayristirici()
    metin, olaylar = a.besle("[jest:takla_at] deneme")
    assert olaylar == [] and a.bilinmeyen == ["takla_at"]
    assert "takla_at" not in metin


def test_kapanmamis_isaretci_veri_kaybettirmez():
    a = Ayristirici()
    a.besle("bitmemiş [poz:düşü")
    kalan, _ = a.bitir()
    assert kalan == "[poz:düşü", "yarım işaretçi kaybolmamalı"


def test_kullanici_enjeksiyonu_soker():
    kirli = "merhaba [jest:el_salla] ve [poz:uyuyor]"
    assert "[" not in temizle(kirli) and "jest" not in temizle(kirli)


def test_gecersiz_hiz_normale_duser():
    a = Ayristirici()
    _, o = a.besle("[jest:el_salla:ışık_hızı]")
    assert o[0].hiz == "normal"


def test_isaretciler_gorunur_metinden_cikar():
    a = Ayristirici()
    m, _ = a.besle("[poz:yazıyor]Kod yazıyorum.[jest:işaret_et] Şuraya bak.")
    assert "[" not in m and "poz" not in m
    assert m == "Kod yazıyorum. Şuraya bak."


def test_tek_karakterlik_chunklar_da_calisir():
    """En sert akış hali: token token gelirse."""
    a = Ayristirici()
    tam, olaylar = "", []
    for ch in "A [jest:omuz_silk:hızlı] B":
        m, o = a.besle(ch)
        tam += m; olaylar += o
    assert olaylar and olaylar[0].ad == "omuz_silk" and olaylar[0].hiz == "hızlı"
    assert "[" not in tam and tam == "A  B"
