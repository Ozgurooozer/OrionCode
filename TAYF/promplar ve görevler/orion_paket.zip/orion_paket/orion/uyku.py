"""
uyku — Orion uyku/rüya modu. Faz makinesi + yetki kısıtları.

TEMEL İNVARYANT (biyolojiden: REM'de GABA/glisin felci):
    REM fazında üretilen HİÇBİR ŞEY doğrudan dünyaya yazılamaz.
    Ne tool call, ne vault yazımı, ne ağ. Çıktı KARANTİNAya gider,
    uyanık durumda gözden geçirilir.
    Bu güvenlik mekanizmasıdır; olmadığında ajan rüyasını OYNAR.

FAZLAR ve YETKİLER:
    UYANIK    : tool + vault-yaz + ağ            (normal iş)
    NREM_HAFIF: yalnız yerel bakım, LLM yok      (dedupe, TTL, indeks)
    NREM_DERIN: vault-yaz VAR, tool/ağ YOK       (konsolidasyon, düşük sıcaklık)
    REM       : hiçbir yazma yok, sadece üretim  (yüksek sıcaklık, karantina)

# ASSUMPTION(rem-paralysis): REM yetkileri BOŞ kümedir. Bu bir varsayılan değil,
# invaryanttır; aşağıdaki assert ve testler onu korur.

ARAYÜZ:
  UykuMotoru(vault, uretici)
    .baski_ekle(token)        -> None   ; iş yapıldıkça uyku borcu birikir
    .uyumali_mi(bosta_sn)     -> bool   ; boşta VEYA borç eşiği aşıldıysa
    .dongu_kos(dongu=1)       -> Rapor  ; NREM->REM sırayla, kesilebilir
    .karantina                -> list[Oneri]  ; REM çıktıları, henüz yazılmadı
    .onayla(oneri_id)         -> None   ; uyanıkken; ANCAK çapasız olarak yazar
  Hata modları: ValueError (negatif baskı, dongu<1), PermissionError (faz ihlali)
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from enum import Enum

log = logging.getLogger("orion.uyku")


class Faz(Enum):
    UYANIK = "uyanik"
    NREM_HAFIF = "nrem_hafif"
    NREM_DERIN = "nrem_derin"
    REM = "rem"


# Faz -> izinli eylemler. REM kasten BOŞ.
YETKI: dict[Faz, frozenset[str]] = {
    Faz.UYANIK: frozenset({"tool", "vault_yaz", "ag"}),
    Faz.NREM_HAFIF: frozenset({"vault_yaz"}),
    Faz.NREM_DERIN: frozenset({"vault_yaz"}),
    Faz.REM: frozenset(),
}
assert YETKI[Faz.REM] == frozenset(), "REM felci ihlal edildi"


@dataclass(frozen=True)
class Oneri:
    """REM ürünü. Gözlem DEĞİL, üretim -> tanım gereği çapasız."""
    oneri_id: str
    metin: str
    dayanak: tuple[str, ...]     # hangi episod/semantik öğelerden türedi


@dataclass
class Rapor:
    konsolide: int = 0
    budandi: int = 0
    oneri: int = 0
    engellenen_eylem: list[str] = field(default_factory=list)


class UykuMotoru:
    ESIK_BORC = 50_000          # token; aşılırsa uyku ZORUNLU
    BOSTA_ESIK_SN = 300

    def __init__(self, vault, uretici):
        """uretici(prompt, sicaklik) -> str  (Ollama ya da API; bkz. surucu.py)"""
        self.vault = vault
        self.uretici = uretici
        self.faz = Faz.UYANIK
        self.borc = 0
        self.karantina: list[Oneri] = []
        self.uretilen = 0          # REM'in ürettiği toplam
        self.onaylanan = 0         # uyanıkken kabul edilen
        self.reddedilen = 0        # uyanıkken elenen — PAYDA için şart

    # --- yetki kapısı ---------------------------------------------------
    def _izin(self, eylem: str) -> None:
        if eylem not in YETKI[self.faz]:
            # GÖZLEMLENEBİLİRLİK: sessiz engelleme en tehlikeli hal.
            log.warning("faz=%s eylem=%s ENGELLENDİ", self.faz.value, eylem)
            raise PermissionError(f"{self.faz.value} fazında '{eylem}' yasak")

    # --- baskı ----------------------------------------------------------
    def baski_ekle(self, token: int) -> None:
        if token < 0:
            raise ValueError("token negatif olamaz")
        self.borc += token

    def uyumali_mi(self, bosta_sn: float) -> bool:
        return bosta_sn >= self.BOSTA_ESIK_SN or self.borc >= self.ESIK_BORC

    # --- fazlar ---------------------------------------------------------
    def _nrem_derin(self, rapor: Rapor) -> None:
        """Konsolidasyon: working/episodic -> semantic. Düşük sıcaklık."""
        self.faz = Faz.NREM_DERIN
        for eid, metin in list(self.vault._episodes.items()):
            ozet = self.uretici(f"Tek cümlede kalıcı bilgi çıkar:\n{metin}", 0.1)
            self._izin("vault_yaz")
            self.vault.write_semantic(f"sem_{eid}", ozet.strip(), derived_from=eid)
            rapor.konsolide += 1

    def _budama(self, rapor: Rapor) -> None:
        """
        Sinaptik budama: gereksiz bağlantı KOPARILIR. Ama üst sınır var —
        aşırı uyku zararlı. Bir episodu, çok sayıda semantik öğenin TEK
        çapasıysa sıkıştırma: onları öksüz bırakır (vault.py'da test edildi).
        """
        for eid in list(self.vault._episodes):
            bagli = sum(1 for s in self.vault._semantic.values()
                        if s.derived_from == eid)
            if bagli == 0:                      # hiçbir şeyi taşımıyor -> at
                self.vault.compact_episode(eid)
                rapor.budandi += 1
            elif bagli > 3:
                log.info("episod %s korunuyor: %d öğenin tek çapası", eid, bagli)

    def _rem(self, rapor: Rapor) -> None:
        """Üretken yeniden birleştirme. Yüksek sıcaklık. HİÇBİR YAZMA YOK."""
        self.faz = Faz.REM
        parcalar = [s.text for s in self.vault._semantic.values()][:8]
        if not parcalar:
            return
        cikti = self.uretici(
            "Aşağıdaki notlar arasında daha önce fark edilmemiş bir bağlantı "
            "öner. Tek cümle:\n" + "\n".join(f"- {p}" for p in parcalar), 0.95)
        # Yazmaya KALKIŞ ve engellendiğini kaydet — invaryant sessiz kalmasın.
        try:
            self._izin("vault_yaz")
            raise AssertionError("REM yazabildi: felç ihlali")
        except PermissionError:
            rapor.engellenen_eylem.append("vault_yaz")
        self.karantina.append(
            Oneri(f"rem_{self.uretilen:03d}", cikti.strip(),
                  tuple(parcalar[:3])))
        self.uretilen += 1
        rapor.oneri += 1

    def dongu_kos(self, dongu: int = 1) -> Rapor:
        if dongu < 1:
            raise ValueError("dongu >= 1 olmalı")
        rapor = Rapor()
        try:
            for _ in range(dongu):
                self.faz = Faz.NREM_HAFIF
                self._nrem_derin(rapor)
                self._budama(rapor)
                self._rem(rapor)
        finally:
            # Uyanma ATOMİK olmalı. Kısmi geçiş = uyku felci / uyurgezerlik.
            self.faz = Faz.UYANIK
        self.borc = 0
        return rapor

    # --- uyanıkken gözden geçirme --------------------------------------
    def reddet(self, oneri_id: str) -> None:
        """Reddetmek de KAYIT: payda olmadan onay oranı ölçülemez."""
        o = next((x for x in self.karantina if x.oneri_id == oneri_id), None)
        if o is None:
            raise ValueError(f"karantinada yok: {oneri_id}")
        self.karantina.remove(o)
        self.reddedilen += 1

    def verim(self) -> dict:
        """
        ÜRETİLEN sayısı gösteriş metriğidir (bkz. AlphaFold eleştirisi:
        milyonlarca protein üretildi, çok azı işlevseldi). Anlamlı olan oran.
        Payda = onaylanan + reddedilen. Bakılmamış öneri paydaya girmez;
        girseydi 'henüz karar verilmedi' ile 'reddedildi' karışırdı.
        """
        karar = self.onaylanan + self.reddedilen
        return {"uretilen": self.uretilen, "onaylanan": self.onaylanan,
                "reddedilen": self.reddedilen, "bekleyen": len(self.karantina),
                "onay_orani": None if karar == 0 else self.onaylanan / karar}

    def onayla(self, oneri_id: str) -> None:
        """
        Rüya ürünü ancak UYANIKKEN ve ÇAPASIZ olarak vault'a girer.
        derived_from=None -> retrieve() onu anchored=False döndürür ->
        format_for_agent onu karar gerekçesi olarak SUNMAZ.
        """
        if self.faz is not Faz.UYANIK:
            raise PermissionError("onay yalnız uyanıkken")
        o = next((x for x in self.karantina if x.oneri_id == oneri_id), None)
        if o is None:
            raise ValueError(f"karantinada yok: {oneri_id}")
        self.vault.write_semantic(o.oneri_id, o.metin, derived_from=None)
        self.karantina.remove(o)
        self.onaylanan += 1
