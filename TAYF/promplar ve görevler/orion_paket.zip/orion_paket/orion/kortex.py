"""
kortex — modelin iç durumundan aktüatöre köprü. BCI mimarisinin birebir karşılığı.

    EEG        -> Sensor      : gizli katman aktivasyonu / logprob / entropi
    decoder    -> Decoder     : sinyal -> sınıf (EĞİTİLİR, okunmaz)
    omurilik   -> Kapi        : hangi sınıf hangi yolu kullanabilir
    TMS/kas    -> Efektor     : sprite, prefetch, MCP tool

TEMEL İNVARYANT (uyku.py'daki REM felcinin ikizi):
    Düşünce sinyali YALNIZCA geri alınabilir eylemi ateşleyebilir.
    Geri alınamaz eylem, güven %100 olsa bile refleks yolundan geçemez;
    argümanlı ve gerekçeli metin kanalını bekler.
    Gerekçe: sinyal SINIF taşır, ARGÜMAN taşımaz (deneyde kanal 2 bit).

# ASSUMPTION(no-args-in-signal): refleks eylemleri parametresiz ya da önceden
# bağlanmış olmalı. Aşağıdaki assert bunu korur; ihlali sessizce geçerse
# sistem, argümanı halüsine eden bir aktüatöre dönüşür.

ARAYÜZ:
  Sinyal(vektor, kaynak, token_idx)
  Decoder.egit(ornekler) -> dict   ; kör doğruluk raporu döner
  Decoder.coz(sinyal)    -> (sinif, guven)
  Kapi.gecir(sinif, guven) -> Yol  ; REFLEKS | ISTEMLI | RED
  Kopru.tik(sinyal)      -> Karar
  Hata modları: ValueError (boş eğitim seti, sınıf tanımsız),
                PermissionError (geri alınamaz eylem refleks yolunda)
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from enum import Enum

log = logging.getLogger("orion.kortex")


class Yol(Enum):
    REFLEKS = "refleks"      # düşünce doğrudan ateşler
    ISTEMLI = "istemli"      # metin kanalını bekle
    RED = "red"              # güven yetersiz, hiçbir şey yapma


@dataclass(frozen=True)
class Eylem:
    ad: str
    geri_alinabilir: bool
    parametresiz: bool


# Refleks yolunda izin verilenler. Hepsi geri alınabilir VE parametresiz.
KATALOG: dict[str, Eylem] = {
    "sprite_sag":   Eylem("sprite_sag", True, True),
    "sprite_sol":   Eylem("sprite_sol", True, True),
    "sprite_zipla": Eylem("sprite_zipla", True, True),
    "prefetch":     Eylem("prefetch", True, True),      # cache ısıt
    "vurgula":      Eylem("vurgula", True, True),       # UI
    # aşağıdakiler asla refleks olamaz
    "dosya_yaz":    Eylem("dosya_yaz", False, False),
    "kabuk":        Eylem("kabuk", False, False),
    "ag_istek":     Eylem("ag_istek", False, False),
}

for _e in KATALOG.values():
    # ASSUMPTION(no-args-in-signal): geri alınabilir ama parametreli bir eylem
    # refleks kataloğuna giremez; sinyal argüman taşımaz.
    assert not (_e.geri_alinabilir and not _e.parametresiz), \
        f"{_e.ad}: geri alınabilir ama parametreli — refleks olamaz"


@dataclass(frozen=True)
class Sinyal:
    vektor: tuple[float, ...]
    kaynak: str          # "hidden_L14" | "logprob" | "entropi"
    token_idx: int


@dataclass
class Karar:
    sinif: str
    guven: float
    yol: Yol
    gerekce: str


class Decoder:
    """
    Lineer prob. Sinyal -> sınıf. OKUNMAZ, EĞİTİLİR — tıpkı EEG'de olduğu gibi
    hangi bölgenin neye karşılık geldiği onlarca yıllık etiketli veriden geldi.
    """

    def __init__(self, esik: float = 0.75):
        self.esik = esik
        self._merkez: dict[str, tuple[float, ...]] = {}

    def egit(self, ornekler: list[tuple[Sinyal, str]]) -> dict:
        if not ornekler:
            raise ValueError("boş eğitim seti")
        toplam: dict[str, list[list[float]]] = {}
        for s, etiket in ornekler:
            toplam.setdefault(etiket, []).append(list(s.vektor))
        for etiket, vs in toplam.items():
            n = len(vs)
            self._merkez[etiket] = tuple(sum(c) / n for c in zip(*vs))
        # KALİBRASYON: eğitim setinde kendi doğruluğunu ölç. Bu bir üst sınır;
        # tutmuyorsa sinyal ayırt edici değil, model kötü değil.
        dogru = sum(1 for s, e in ornekler if self.coz(s)[0] == e)
        return {"sinif": len(toplam), "ornek": len(ornekler),
                "egitim_dogrulugu": dogru / len(ornekler)}

    def coz(self, sinyal: Sinyal) -> tuple[str, float]:
        if not self._merkez:
            raise ValueError("decoder eğitilmedi")
        mesafe = {
            e: sum((a - b) ** 2 for a, b in zip(m, sinyal.vektor)) ** 0.5
            for e, m in self._merkez.items()
        }
        en_yakin = min(mesafe, key=mesafe.get)
        siralı = sorted(mesafe.values())
        # güven = en yakın ile ikinci arasındaki ayrım (tek sınıfta 1.0)
        guven = 1.0 if len(siralı) < 2 else \
            min(1.0, (siralı[1] - siralı[0]) / (siralı[1] + 1e-9))
        return en_yakin, guven


class Kapi:
    """Omurilik. Güven YETKİ DEĞİLDİR."""

    def __init__(self, esik: float = 0.75):
        self.esik = esik

    def gecir(self, sinif: str, guven: float) -> tuple[Yol, str]:
        eylem = KATALOG.get(sinif)
        if eylem is None:
            raise ValueError(f"tanımsız sınıf: {sinif}")
        if not eylem.geri_alinabilir:
            # Güven ne olursa olsun. Bu invaryant, eşikle pazarlık etmez.
            log.info("kapı: %s geri alınamaz -> istemli yol (guven=%.2f)",
                     sinif, guven)
            return Yol.ISTEMLI, "geri alınamaz: argüman ve gerekçe gerekli"
        if guven < self.esik:
            return Yol.RED, f"güven {guven:.2f} < {self.esik}"
        return Yol.REFLEKS, "geri alınabilir ve parametresiz"


class Kopru:
    def __init__(self, decoder: Decoder, kapi: Kapi, efektor=None):
        self.decoder, self.kapi = decoder, kapi
        self.efektor = efektor or (lambda ad: None)
        self.gecmis: list[Karar] = []

    def tik(self, sinyal: Sinyal) -> Karar:
        sinif, guven = self.decoder.coz(sinyal)
        yol, gerekce = self.kapi.gecir(sinif, guven)
        if yol is Yol.REFLEKS:
            self.efektor(sinif)
        k = Karar(sinif, guven, yol, gerekce)
        self.gecmis.append(k)
        return k

    def rapor(self) -> dict:
        """GÖZLEMLENEBİLİRLİK: refleks/istemli/red dağılımı."""
        d = {y.value: 0 for y in Yol}
        for k in self.gecmis:
            d[k.yol.value] += 1
        return d
