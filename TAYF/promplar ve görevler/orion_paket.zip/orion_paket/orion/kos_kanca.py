"""Senin makinende: python kos_kanca.py            -> insan için, renkli
                    python kos_kanca.py --jsonl    -> Godot/Unity borusu için
Godot: OS.execute ya da pipe ile oku, her satır bir olay."""
import json, sys, urllib.request
from kanca import Sahne
from sahne import SISTEM_ISTEMI, temizle

HAT = "--jsonl" in sys.argv

def akit(soru, model="qwen2.5-coder:7b"):
    p = {"model": model, "stream": True,
         "messages": [{"role": "system", "content": SISTEM_ISTEMI},
                      {"role": "user", "content": temizle(soru)}]}
    r = urllib.request.Request("http://localhost:11434/api/chat",
        data=json.dumps(p).encode(), headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(r, timeout=180) as resp:
        for satir in resp:
            if satir.strip():
                d = json.loads(satir)
                if not d.get("done"):
                    yield d["message"]["content"]

s = Sahne()

if HAT:
    # Süreçler arası: her olay tek satır JSON, anında akar.
    s.abone("*", lambda o: print(json.dumps(o.dict(), ensure_ascii=False),
                                 flush=True))
else:
    s.abone("jest", lambda o: print(f"\n  ▶ JEST {o.ad} ({o.hiz}) @{o.konum}",
                                    flush=True))
    s.abone("poz",  lambda o: print(f"\n  ▷ POZ  {o.ad} @{o.konum}", flush=True))

for chunk in akit(sys.argv[1] if len(sys.argv) > 1 and not HAT
                  else "Merhaba, bugün ne üzerinde çalışıyorsun?"):
    metin, _ = s.besle(chunk)
    if not HAT:
        print(metin, end="", flush=True)
kalan, _ = s.bitir()
if not HAT:
    print(kalan)
    print(f"\n\nson poz: {s.poz} | olay: {len(s.olaylar)} | "
          f"bilinmeyen: {s.bilinmeyen} | patlayan abone: {s.hatali}")
