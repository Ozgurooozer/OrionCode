"""
DÜŞMAN TESTİ — naif "uyku modu" tasarımını kıran senaryolar.

Naif tasarım: uyku = arka planda LLM koştur, çıktısını hafızaya yaz.
Kıran senaryo: üretilen içerik gözlemlenmiş içerikten ayırt edilemez hale
gelir ve ajan kendi rüyasını kaynak sanır (uyurgezerlik / REM davranış
bozukluğu). Aşağıdaki testler tam bu noktayı korur.
"""
import pytest

from uyku import UykuMotoru, Faz, YETKI, Oneri
from vault import Vault, format_for_agent


def sahte_uretici(prompt: str, sicaklik: float) -> str:
    return f"uretilmis(t={sicaklik})"


def kur() -> UykuMotoru:
    v = Vault()
    v.write_episode("ep01", "kullanıcı port ayarını 9876 yaptı")
    v.write_episode("ep02", "vault dört katmanlı kararlaştırıldı")
    return UykuMotoru(v, sahte_uretici)


def test_rem_yetkisi_bos():
    assert YETKI[Faz.REM] == frozenset()


def test_negatif_baski_reddedilir():
    with pytest.raises(ValueError):
        kur().baski_ekle(-1)


def test_dongu_sifir_reddedilir():
    with pytest.raises(ValueError):
        kur().dongu_kos(0)


def test_ASIL_rem_yazamaz_uyurgezerlik_yok():
    """REM fazında vault yazımı ENGELLENMELİ ve kaydedilmeli."""
    m = kur()
    r = m.dongu_kos()
    assert "vault_yaz" in r.engellenen_eylem, "REM yazabildi = uyurgezerlik"
    assert r.oneri >= 1
    # öneri karantinada, vault'ta DEĞİL
    assert all(not k.startswith("rem_") for k in m.vault._semantic)


def test_uyanma_atomik_hata_olsa_bile():
    """Faz geçişi yarım kalırsa uyku felci/uyurgezerlik olur."""
    v = Vault()
    v.write_episode("ep01", "x")

    def patlayan(prompt, sicaklik):
        raise RuntimeError("model çöktü")

    m = UykuMotoru(v, patlayan)
    with pytest.raises(RuntimeError):
        m.dongu_kos()
    assert m.faz is Faz.UYANIK, "çökmede UYANIK'a dönmeli"


def test_onay_uyanik_disinda_reddedilir():
    m = kur()
    m.dongu_kos()
    m.faz = Faz.REM
    with pytest.raises(PermissionError):
        m.onayla(m.karantina[0].oneri_id)


def test_ASIL_onaylanan_ruya_capasiz_kalir():
    """
    Rüya ürünü onaylansa BİLE karar gerekçesi olarak sunulmamalı.
    vault.py'daki çapa mekanizmasıyla otomatik sağlanmalı.
    """
    m = kur()
    m.dongu_kos()
    oid = m.karantina[0].oneri_id
    m.onayla(oid)
    bulunan = {r.source_id: r for r in m.vault.retrieve("uretilmis", k=10)}
    assert bulunan[oid].anchored is False
    çıktı = format_for_agent(list(bulunan.values()))
    kaynakli = çıktı.split("TANIDIK")[0]
    assert oid not in kaynakli, "rüya, karar gerekçesi bölümünde görünmemeli"


def test_budama_tek_capayi_korur():
    """Aşırı uyku zararlı: çok öğenin tek çapası olan episod silinmemeli."""
    v = Vault()
    v.write_episode("ep01", "kritik oturum")
    for i in range(5):
        v.write_semantic(f"s{i}", f"bilgi {i}", derived_from="ep01")
    m = UykuMotoru(v, sahte_uretici)
    m.dongu_kos()
    assert "ep01" in v._episodes, "5 öğenin tek çapası budanmamalı"


def test_uyku_baskisi_zorlar():
    m = kur()
    assert m.uyumali_mi(bosta_sn=0) is False
    m.baski_ekle(60_000)
    assert m.uyumali_mi(bosta_sn=0) is True, "borç eşiği uykuyu zorlamalı"


def test_verim_uretilen_degil_orani_olcer():
    """AlphaFold eleştirisi: üretilen sayısı gösteriş, onay oranı gerçek."""
    m = kur(); m.dongu_kos()
    assert m.verim()["onay_orani"] is None, "karar yokken oran uydurulmamalı"
    m.onayla(m.karantina[0].oneri_id)
    v = m.verim()
    assert v["uretilen"] >= 1 and v["onaylanan"] == 1 and v["onay_orani"] == 1.0


def test_reddetme_paydaya_girer():
    m = kur(); m.dongu_kos(dongu=2)
    ilk = m.karantina[0].oneri_id
    m.reddet(ilk)
    v = m.verim()
    assert v["reddedilen"] == 1 and v["onay_orani"] == 0.0


def test_bekleyen_paydaya_girmez():
    m = kur(); m.dongu_kos(dongu=2)
    m.onayla(m.karantina[0].oneri_id)
    v = m.verim()
    assert v["bekleyen"] >= 1 and v["onay_orani"] == 1.0
