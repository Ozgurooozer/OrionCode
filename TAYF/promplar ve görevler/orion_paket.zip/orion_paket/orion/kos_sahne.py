"""Senin makinende: python kos_sahne.py  (Ollama ayakta olmalı)
Model anlatım işaretçileriyle konuşur, ayrıştırıcı animasyon olayı üretir."""
import json, urllib.request
from sahne import Ayristirici, SISTEM_ISTEMI, temizle

def akit(soru, model="qwen2.5-coder:7b"):
    payload = {"model": model, "stream": True,
               "messages": [{"role": "system", "content": SISTEM_ISTEMI},
                            {"role": "user", "content": temizle(soru)}]}
    req = urllib.request.Request("http://localhost:11434/api/chat",
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=180) as r:
        for satir in r:
            if satir.strip():
                p = json.loads(satir)
                if not p.get("done"):
                    yield p["message"]["content"]

a = Ayristirici()
print("--- kullanıcıya görünen ---")
for chunk in akit("Merhaba, bugün ne üzerinde çalışıyorsun?"):
    metin, olaylar = a.besle(chunk)
    print(metin, end="", flush=True)
    for o in olaylar:
        print(f"\n  >> ANİMASYON {o.tur}:{o.ad} hız={o.hiz}", flush=True)
kalan, _ = a.bitir()
print(kalan)
print(f"\nson poz: {a.poz} | bilinmeyen işaretçi: {a.bilinmeyen}")
