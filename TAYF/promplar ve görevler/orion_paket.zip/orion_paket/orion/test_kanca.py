"""DÜŞMAN TESTİ — naif "ham chunk uzunluğunu say" tasarımını kırar."""
import json
import pytest
from kanca import Sahne


def test_ASIL_konum_gorunur_metne_gore():
    """
    Naif hata: ham chunk uzunluğunu saymak. İşaretçi karakterleri de sayılır,
    konumlar kayar ve animasyon yanlış cümlede oynar.
    """
    s = Sahne()
    tam = ""
    for ch in "Selam [jest:el_salla] dostum":   # token token besle
        m, _ = s.besle(ch)
        tam += m
    assert tam == "Selam  dostum"
    o = s.olaylar[0]
    assert o.konum == len("Selam "), f"konum kaydı: {o.konum}"


def test_iki_olay_artan_konumda():
    s = Sahne()
    for ch in "[poz:düşünüyor]abc[jest:el_kaldır]def":
        s.besle(ch)
    konumlar = [o.konum for o in s.olaylar]
    assert konumlar == sorted(konumlar) and konumlar[0] == 0
    assert konumlar[1] == 3


def test_abone_dekorator_olarak():
    s = Sahne()
    gelen = []

    @s.abone("jest")
    def _(o):
        gelen.append(o.ad)

    for ch in "[jest:omuz_silk:hızlı]":
        s.besle(ch)
    assert gelen == ["omuz_silk"]


def test_yildiz_abonesi_hepsini_alir():
    s = Sahne(); hepsi = []
    s.abone("*", lambda o: hepsi.append(o.tur))
    for ch in "[poz:yazıyor]x[jest:el_salla]":
        s.besle(ch)
    assert hepsi == ["poz", "jest"]


def test_ASIL_patlayan_abone_akisi_oldurmez():
    s = Sahne(); saglam = []
    s.abone("jest", lambda o: (_ for _ in ()).throw(RuntimeError("çöktü")))
    s.abone("jest", saglam.append)
    for ch in "[jest:el_salla] devam":
        s.besle(ch)
    assert s.hatali == 1 and len(saglam) == 1, "sağlam abone de çalışmalı"


def test_jsonl_satirlari_parse_edilebilir():
    s = Sahne()
    for ch in "[poz:şaşkın]merhaba[jest:işaret_et:yavaş]":
        s.besle(ch)
    satirlar = list(s.jsonl())
    assert len(satirlar) == 2
    e = json.loads(satirlar[1])
    assert e["ad"] == "işaret_et" and e["hiz"] == "yavaş" and e["konum"] == 7


def test_bilinmeyen_isaretci_olay_uretmez_ama_sayilir():
    s = Sahne()
    for ch in "[jest:takla_at]abc":
        s.besle(ch)
    assert s.olaylar == [] and s.bilinmeyen == ["takla_at"]


def test_bolunmus_isaretci_konumu_bozmaz():
    s = Sahne()
    m1, _ = s.besle("ab[jest:el_ka")
    m2, o2 = s.besle("ldır] cd")
    assert (m1 + m2) == "ab cd"
    assert o2[0].konum == 2, f"bölünmüş işaretçide konum kaydı: {o2[0].konum}"
