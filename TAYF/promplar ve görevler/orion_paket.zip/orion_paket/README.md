# Orion Paket

Yerel AI agent'ın bellek/uyku/algı/anlatım çekirdeği + Kuş-Su düşünme çerçevesi.

## Hızlı başlangıç
1. `CLAUDE.md` oku — çalışma disiplini ve mimari temel.
2. `orion/` içinde `python -m pytest -q` → 57 test geçmeli.
3. `GOREVLER.md` sırayla — baştaki ucuz ölçümler sonraki adımların yönünü belirler.
4. Her görev sonrası `kacirma_gunlugu.md` güncelle.

## Yapı
- `orion/`  — modüller (vault, uyku, kortex, sahne, kanca, probe, surucu) + testler + kos_*.py ölçüm betikleri
- `kusu/`   — kussu_v7.txt (kod yazma çerçevesi) + kussu_meta.txt (çerçeveyi değiştirme kuralları)
