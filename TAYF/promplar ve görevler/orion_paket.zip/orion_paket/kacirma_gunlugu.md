# Kaçırma Günlüğü

Çerçevenin veya testlerin YAKALAMADIĞI ama sonradan çıkan hatalar.
Bu payda. Yakaladıklarımız zaten sürüm kaydında; burası kaçırdıklarımız.

Format: `tarih | nerede | çerçeve/test neden kaçırdı`

<!-- örnek (sil):
2026-02-01 | vault gerçek entegrasyon | test bellek-içi sözlükle geçiyordu, gerçek arka uçta çapa çözümü N+1 sorgu yaptı, test bunu göremezdi
-->
